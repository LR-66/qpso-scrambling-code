"""
interference.py
===============
Interference pre-processing and the scrambling-code codebook.

Implements:
  * weak-interference filtering via the median threshold (Section 4.2),
  * the mapping weight between user pairs (Eq. (2)),
  * a unit-norm scrambling-code codebook from which the optimizers assign one
    code per co-scheduled user.
"""

import numpy as np

from config import N_TX, CO_SCHEDULED_USERS


def threshold_filter(W, percentile=50):
    """Weak-interference filtering (Section 4.2).

    Retains only interference links whose magnitude exceeds the chosen
    percentile of the off-diagonal entries, drives the rest to zero, and keeps
    the matrix symmetric / positive semi-definite.  The paper selects the median
    (50th percentile) as the best trade-off between sparsity and structure.
    """
    off = W - np.diag(np.diag(W))
    thr = np.percentile(np.abs(off), percentile)
    mask = np.abs(off) >= thr
    Wf = np.where(mask, W, 0.0)
    Wf = 0.5 * (Wf + Wf.T)
    tr = np.trace(Wf)
    if tr > 0:
        Wf = Wf / tr
    return Wf, float(thr)


def mapping_weight(user_pos, channel_gain, cov_weight=1.0, adjust=1.0):
    """Pairwise mapping weight w_ij (Eq. (2)).

    w_ij = adjust * ||x_i - x_j|| * c_ij * rho_ij

    where x_i is the spatial position, c_ij the unit interference-covariance
    weight and rho_ij the channel-gain correlation coefficient.  Used to rank
    the user pairs that most require separated scrambling codes.
    """
    dist = np.linalg.norm(user_pos[0] - user_pos[1])
    corr = np.dot(channel_gain[0], channel_gain[1]) / (
        np.linalg.norm(channel_gain[0]) * np.linalg.norm(channel_gain[1]) + 1e-9)
    return float(adjust * cov_weight * dist * corr)


def build_codebook(n_codes, rng):
    """Unit-norm scrambling-code codebook (columns of shape (N_TX, n_codes)).

    Codes are drawn from a Gaussian ensemble and L2-normalised, giving a rich
    set of approximately orthogonal candidates for the discrete assignment.
    """
    raw = rng.standard_normal((N_TX, n_codes))
    norms = np.linalg.norm(raw, axis=0, keepdims=True)
    return raw / norms


def positions_grid(n_users):
    """Synthetic spatial positions of co-scheduled users (Section 3.1.2)."""
    rng = np.random.default_rng(7)
    return rng.uniform(0, 1, size=(n_users, 2))


def codes_from_indices(codebook, idx):
    """Assemble the (N_TX x U) scrambling-code matrix for an index assignment."""
    return codebook[:, np.asarray(idx, dtype=int)]
