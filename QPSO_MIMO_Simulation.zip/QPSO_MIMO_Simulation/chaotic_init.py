"""
chaotic_init.py
===============
Logistic chaotic perturbation for the QPSO population initialisation
(Sections 3.2.1 - 3.2.2) and the distribution-entropy diagnostic (Fig. 2).

Eq. (3)  z_{k+1} = mu * z_k * (1 - z_k)
Eq. (4)  x_0 = (1 - beta) * z + beta * v_pc
"""

import numpy as np

from config import (
    LOGISTIC_MU, LOGISTIC_SEED_LO, LOGISTIC_SEED_HI,
    GUIDANCE_FUSION_RATIO, SEGMENT_FUSION_COUNT,
)


def logistic_sequence(length, mu=LOGISTIC_MU, seed=None, rng=None):
    """Generate a Logistic chaotic sequence of the given length (Eq. (3))."""
    if rng is None:
        rng = np.random.default_rng(0)
    if seed is None:
        seed = rng.uniform(LOGISTIC_SEED_LO, LOGISTIC_SEED_HI)
    z = np.empty(length, dtype=float)
    z[0] = seed
    for k in range(1, length):
        z[k] = mu * z[k - 1] * (1.0 - z[k - 1])
    return z


def chaotic_positions(n_particles, dim, principal_component, rng,
                      mu=LOGISTIC_MU, beta=GUIDANCE_FUSION_RATIO,
                      intensity=0.15):
    """Initialise particle positions in [0, 1]^dim with chaotic perturbation.

    Multi-segment interval perturbation fusion (Section 3.2.2): the Logistic
    sequence is split into SEGMENT_FUSION_COUNT equal segments and each segment
    is cross-applied to different dimensions, then fused with the dominant
    interference principal component v_pc through the guidance ratio beta
    (Eq. (4)).  The ``intensity`` argument scales the cross-perturbation
    amplitude (used by Fig. 2).  The result is normalised to the legal
    scrambling-code space.
    """
    pos = np.empty((n_particles, dim), dtype=float)
    seg = max(dim // SEGMENT_FUSION_COUNT, 1)
    # project the dominant interference eigenvector onto the position dimension
    guide = principal_component[:dim].copy()
    guide = (guide - guide.min())
    guide = guide / (guide.max() + 1e-9) if guide.max() > 0 else guide
    for i in range(n_particles):
        seq = logistic_sequence(dim, mu=mu, rng=rng)
        # multi-segment cross perturbation
        fused = seq.copy()
        for s in range(SEGMENT_FUSION_COUNT):
            start = (s * seg) % dim
            roll = np.roll(seq, (s + 1) * 3)
            fused = fused + intensity * roll
        # directional guidance from the dominant interference eigenvector
        x0 = (1.0 - beta) * fused + beta * guide
        # squash to [0, 1]
        x0 = (x0 - x0.min()) / (x0.max() - x0.min() + 1e-9)
        pos[i] = x0
    return pos


def distribution_entropy(positions, bins=20):
    """Shannon entropy of the particle distribution in the code space (Fig. 2).

    Quantifies how balanced the initial particle swarm is across the
    scrambling-code search space.  Higher entropy -> broader, more diverse
    coverage.
    """
    flat = positions.ravel()
    hist, _ = np.histogram(flat, bins=bins, range=(0.0, 1.0))
    p = hist / (hist.sum() + 1e-12)
    p = p[p > 0]
    return float(-np.sum(p * np.log(p)))
