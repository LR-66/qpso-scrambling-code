"""
main.py
=======
Entry point for the improved-QPSO scrambling-code mapping simulation.

Run it from PyCharm (or the command line) with:

    python main.py            # full experiment (N_REALIZATIONS from config.py)
    python main.py --fast     # quick smoke test (8 realizations)

The script reproduces every result table (Fig. 7, Fig. 8, Fig. 9, Tables 2-4)
and every figure (Fig. 2-9) reported in the manuscript.  Output is written to
./results (CSV) and ./figures (PNG).  Only NumPy and Matplotlib are required.
"""

import argparse
import os
import sys

import numpy as np

# Make the project root importable when launched from PyCharm or the terminal.
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import config
from simulation import run_main_experiment, run_component_experiment, \
    write_all_tables, print_summary
from plotting import generate_all_figures


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fast", action="store_true",
                        help="run a quick smoke test with fewer realizations")
    args = parser.parse_args()

    if args.fast:
        config.N_REALIZATIONS = 8

    print("Improved QPSO scrambling-code mapping simulation")
    print(f"  realizations = {config.N_REALIZATIONS}, "
          f"population = {config.POP_SIZE}, max_iter = {config.MAX_ITER}")
    print("Running main experiment (Fig. 7 / 8 / 9, Tables 2 / 3) ...")
    exp = run_main_experiment()

    print("Running component-contribution self-check (Table 4) ...")
    comp_rows = run_component_experiment()
    i_full = np.mean([r[0] for r in comp_rows])
    i_std = np.mean([r[1] for r in comp_rows])
    print(f"  mean I_res: improved = {i_full:.4e}, standard QPSO = {i_std:.4e} "
          f"(improved lower: {i_full <= i_std})")

    write_all_tables(exp)
    print_summary(exp)

    print("Rendering figures (Fig. 2-9) ...")
    generate_all_figures(exp)

    print("\nDone. Inspect ./results and ./figures.")


if __name__ == "__main__":
    main()
