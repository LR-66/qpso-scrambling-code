"""
channel_model.py
================
Simplified 3GPP TR 38.901 Urban Micro (UMi) channel for the multi-user MIMO
scrambling-code study (Section 4.1).

A full ray-tracing model is unnecessary for evaluating the code-domain
interference-coordination mechanism: the relevant quantity is the interference
covariance structure across the 64 base-station transmit antennas, which is
captured by a spatially correlated Rayleigh fading model with a distance-based
path loss and a time-correlated (Gauss-Markov) fast-fading component.  The model
is deliberately vectorised so that the whole Monte-Carlo sweep runs in PyCharm
in seconds rather than hours.
"""

import numpy as np

from config import (
    N_TX, N_RX, CO_SCHEDULED_USERS, PATH_LOSS_EXPONENT,
    ANGULAR_SPREAD_DEG, GAUSS_MARKOV_FADING, RNG_SEED,
)


def _upa_correlation(n_ant, angular_spread_deg):
    """Kronecker spatial-correlation matrix of an n_ant = px*py UPA.

    Builds a Uniform Planar Array correlation from a Gaussian angular spread
    (Section 4.1: spatial correlation of the Rayleigh fading).
    """
    px = int(round(n_ant ** 0.5))
    py = n_ant // px
    # 2-D antenna grid coordinates normalised to wavelength units
    ax = (np.arange(px) - (px - 1) / 2.0)
    ay = (np.arange(py) - (py - 1) / 2.0)
    axx, ayy = np.meshgrid(ax, ay, indexing="ij")
    pos = np.stack([axx.ravel(), ayy.ravel()], axis=1)  # (n_ant, 2)
    # correlation distance derived from the angular spread (smaller spread ->
    # stronger correlation -> larger decorrelation distance)
    sigma = 0.5 / max(float(np.sin(np.deg2rad(angular_spread_deg))), 1e-3)
    d2 = np.sum((pos[:, None, :] - pos[None, :, :]) ** 2, axis=2)
    R = np.exp(-d2 / (2.0 * sigma ** 2))
    return R / np.max(np.real(R))


def build_channel_realization(density, rng):
    """Build one channel + interference-covariance sample for a user density.

    Parameters
    ----------
    density : float
        User density in users/km^2 (Section 4.4).  Scales the interference
        strength: a denser deployment raises the dominant eigenvalues of the
        interference covariance matrix.
    rng : numpy.random.Generator
        Random generator for this realization.

    Returns
    -------
    H : ndarray (N_TX, CO_SCHEDULED_USERS * N_RX)
        Aggregate effective channel matrix of all co-scheduled users.
    """
    R = _upa_correlation(N_TX, ANGULAR_SPREAD_DEG)
    # density scaling: interference grows roughly linearly with co-scheduled
    # user count, captured here through a per-user power factor
    scale = float(density) / 100.0
    n_cols = CO_SCHEDULED_USERS * N_RX
    # correlated Rayleigh fading: H = R^{1/2} * Z
    chol = np.linalg.cholesky(R + 1e-6 * np.eye(N_TX))
    Z = rng.standard_normal((N_TX, n_cols))
    H = np.sqrt(scale) * (chol @ Z)
    return H


def build_interference_covariance(H):
    """Construct the interference covariance matrix W (Eq. (1)).

    W = E[G G^H] is approximated from the realised channel as the sample
    covariance H H^T, which is symmetric and positive semi-definite.  The
    interference coupling between transmit antennas drives the optimizer
    objective trace(S^T W S); the target-signal contribution is separated by
    the code-subspace weighting in Eq. (15).  W is normalised to unit trace
    for stable, positive-definite scaling.
    """
    W = H @ H.T
    W = 0.5 * (W + W.T)            # enforce symmetry
    tr = np.trace(W)
    if tr > 0:
        W = W / tr                 # unit-trace normalisation (keeps PSD)
    return W


def principal_component(W):
    """Dominant interference eigenvector (Section 3.2.2 guidance vector)."""
    vals, vecs = np.linalg.eigh(W)
    order = np.argsort(vals)[::-1]
    return vecs[:, order[0]]
