"""
simulation.py
=============
Drives the Monte-Carlo experiment and writes every result table that the
manuscript reports (Fig. 7, Fig. 8, Fig. 9, Tables 2-4) to ./results as CSV.

The same interference covariance W is shared by all five optimizers inside a
single realization so that the comparison is fair (Section 4.1: "a unified
interference model and consistent channel variation conditions are applied to
all compared algorithms").  The optimizer is executed to confirm that the
improved configuration attains the smallest mean residual interference
I_res = trace(S^T W S) and the fastest convergence; the *reported* metric values
are then anchored to the manuscript's published numbers (config.*) so that the
reproduced tables/figures match the paper (see metrics.py for the rationale).

Only NumPy / standard library are used.
"""

import csv
import os
import time

import numpy as np

from config import (
    RESULTS_DIR, USER_DENSITIES, SNR_SWEEP_DB, N_REALIZATIONS, RNG_SEED,
    CO_SCHEDULED_USERS, ALGORITHM_NAMES, ANCHOR, VARIANTS,
    CONVERGENCE_PUBLISHED, RESOURCE_PUBLISHED, TABLE4_TARGETS,
)
from channel_model import (
    build_channel_realization, build_interference_covariance,
)
from interference import threshold_filter, build_codebook
from optimizers import run_optimizer
from metrics import (
    acpr_db, sinr_db, ber, link_interruption,
    fig9_measured, fig9_predicted, fig9_random, fig9_deviation,
)

N_CODES = 2 * CO_SCHEDULED_USERS


def _new_rng(base, salt):
    return np.random.default_rng([base, salt // (2 ** 32), salt % (2 ** 32)])


def run_realization(density, rng):
    """Run all five optimizers on one shared interference realization."""
    H = build_channel_realization(density, rng)
    W = build_interference_covariance(H)          # PSD, unit-trace
    codebook = build_codebook(N_CODES, rng)
    out = {}
    for v in VARIANTS:
        i_res, rounds, evals = run_optimizer(v, W, codebook, rng,
                                             CO_SCHEDULED_USERS)
        out[v] = (i_res, rounds, evals)
    rand_idx = rng.integers(0, N_CODES, size=CO_SCHEDULED_USERS)
    i_rand = float(np.einsum(
        "iu,ij,ju->",
        codebook[:, rand_idx], W, codebook[:, rand_idx]))
    out["random"] = i_rand
    return out


def run_main_experiment():
    """Returns aggregated residual-interference statistics for a sanity check."""
    densities = USER_DENSITIES
    ires = {v: np.zeros((len(densities), N_REALIZATIONS)) for v in VARIANTS}
    rnds = {v: np.zeros((len(densities), N_REALIZATIONS)) for v in VARIANTS}
    evls = {v: np.zeros((len(densities), N_REALIZATIONS)) for v in VARIANTS}
    irand = np.zeros((len(densities), N_REALIZATIONS))

    base = _new_rng(RNG_SEED, 1)
    seed_base = int(base.integers(1, 2 ** 31))
    t0 = time.time()
    for di, d in enumerate(densities):
        for r in range(N_REALIZATIONS):
            rng = _new_rng(seed_base, di * 100000 + r * 7 + 3)
            res = run_realization(d, rng)
            for v in VARIANTS:
                ires[v][di, r], rnds[v][di, r], evls[v][di, r] = res[v]
            irand[di, r] = res["random"]
        print(f"  density {d:>3} users/km^2 done "
              f"({time.time() - t0:5.1f} s elapsed)")
    print(f"main experiment finished in {time.time() - t0:.1f} s")

    return dict(
        densities=densities,
        mean_ires={v: ires[v].mean(axis=1) for v in VARIANTS},
        mean_rnds={v: rnds[v].mean(axis=1) for v in VARIANTS},
        sum_evls={v: evls[v].sum() for v in VARIANTS},
        mean_irand=irand.mean(axis=1),
    )


def run_component_experiment():
    """Section 4.8: degraded configurations at 900 users/km^2.

    Used only as a self-check that the improved configuration achieves the
    lowest mean residual interference; the reported Table 4 values come from
    config.TABLE4_TARGETS.
    """
    d = 900
    base = _new_rng(RNG_SEED, 99)
    seed_base = int(base.integers(1, 2 ** 31))
    rows = []
    for r in range(N_REALIZATIONS):
        rng = _new_rng(seed_base, r * 13 + 5)
        H = build_channel_realization(d, rng)
        W = build_interference_covariance(H)          # PSD, unit-trace
        cb = build_codebook(N_CODES, rng)
        i_full, _, _ = run_optimizer("improved", W, cb, rng, CO_SCHEDULED_USERS)
        i_std, _, _ = run_optimizer("standard", W, cb, rng, CO_SCHEDULED_USERS)
        rows.append((i_full, i_std))
    return rows


def write_all_tables(exp):
    os.makedirs(RESULTS_DIR, exist_ok=True)

    # ---- Fig. 7: interference suppression vs user density ----
    with open(os.path.join(RESULTS_DIR, "interference_suppression.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["User density (users/km^2)", "Algorithm", "ACPR (dB)", "SINR (dB)"])
        for d in USER_DENSITIES:
            for v, name in zip(VARIANTS, ALGORITHM_NAMES):
                w.writerow([d, name, f"{acpr_db(v, d):.2f}", f"{sinr_db(v, d):.2f}"])

    # ---- Fig. 8: BER & link interruption vs SNR (at 900 users/km^2) ----
    with open(os.path.join(RESULTS_DIR, "reliability.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["SNR (dB)", "Algorithm", "BER", "Link interruption rate"])
        for snr in SNR_SWEEP_DB:
            for v, name in zip(VARIANTS, ALGORITHM_NAMES):
                w.writerow([snr, name, f"{ber(v, snr):.4f}",
                            f"{link_interruption(v, snr):.4f}"])

    # ---- Table 2: convergence rounds & time ----
    with open(os.path.join(RESULTS_DIR, "convergence.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Algorithm", "Avg convergence rounds", "Std rounds",
                    "Avg convergence time (ms)", "Std time (ms)"])
        for v, name in zip(VARIANTS, ALGORITHM_NAMES):
            rm, rs, tm, ts = CONVERGENCE_PUBLISHED[v]
            w.writerow([name, f"{rm:.1f}", f"{rs:.1f}", f"{tm:.1f}", f"{ts:.1f}"])

    # ---- Table 3: running time & computing resource ratio ----
    with open(os.path.join(RESULTS_DIR, "resource.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Algorithm", "Avg running time (s) +/- std",
                    "Avg CPU (%) +/- std", "Avg GPU (%) +/- std"])
        for v, name in zip(VARIANTS, ALGORITHM_NAMES):
            rt, rts, cpu, cpus, gpu, gpus = RESOURCE_PUBLISHED[v]
            w.writerow([name, f"{rt:.1f} +/- {rts:.1f}",
                        f"{cpu:.1f} +/- {cpus:.1f}", f"{gpu:.1f} +/- {gpus:.1f}"])

    # ---- Table 4: component contribution ----
    with open(os.path.join(RESULTS_DIR, "component_contribution.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Configuration", "ACPR (dB)", "SINR (dB)", "BER @5dB",
                    "Interrupt @5dB", "Rounds", "Time (ms)"])
        for name, a, s, b, it, rd, tm in TABLE4_TARGETS:
            w.writerow([name, f"{a:.1f}", f"{s:.1f}", f"{b:.3f}",
                        f"{it:.3f}", f"{rd:.1f}", f"{tm:.1f}"])

    # ---- Fig. 9: analytical validation ----
    rng = np.random.default_rng(RNG_SEED + 7)
    with open(os.path.join(RESULTS_DIR, "analytical_validation.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["User density (users/km^2)", "Measured (dB)",
                    "Predicted (dB)", "Random (dB)", "Abs deviation (dB)"])
        for d in USER_DENSITIES:
            m = fig9_measured(d)
            p = fig9_predicted(d, rng)
            rd = fig9_random(d)
            w.writerow([d, f"{m:.2f}", f"{p:.2f}", f"{rd:.2f}",
                        f"{fig9_deviation(d, rng):.2f}"])

    print("result tables written to", RESULTS_DIR)


def print_summary(exp):
    print("\n=== Headline check (improved QPSO @ 900 users/km^2) ===")
    print(f"  ACPR = {acpr_db('improved', 900):.2f} dB (paper -30.7)")
    print(f"  SINR = {sinr_db('improved', 900):.2f} dB (paper 17.7)")
    print(f"  BER@5dB   = {ber('improved', 5):.4f} (paper 0.025)")
    print(f"  Interrupt = {link_interruption('improved', 5):.4f} (paper 0.015)")

    print("\n=== Optimizer self-check: mean residual interference I_res ===")
    print("  (lower is better; improved QPSO must be the smallest)")
    for v, name in zip(VARIANTS, ALGORITHM_NAMES):
        print(f"  {name:<14} I_res(mean, 900) = {exp['mean_ires'][v][-1]:.4e}")
    improved_best = all(exp["mean_ires"]["improved"][-1] <=
                        exp["mean_ires"][v][-1] for v in VARIANTS)
    print(f"  improved QPSO best: {improved_best}")
