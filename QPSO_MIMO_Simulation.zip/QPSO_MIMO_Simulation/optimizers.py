"""
optimizers.py
=============
Scrambling-code assignment optimizers.

The discrete assignment problem is solved by five meta-heuristics that all
minimise the same physically-motivated objective

    I_res(idx) = trace( S(idx)^T W S(idx) )            (Eq. (14)/(6))

where S(idx) are the unit-norm scrambling codes selected from the codebook for
the U co-scheduled users and W is the interference covariance matrix.  Lower
I_res means lower aggregate multi-user interference.

Implemented variants
--------------------
  * "improved"     : improved QPSO - Logistic chaotic init + adaptive
                     contraction-expansion coefficient + multi-round remapping
  * "standard"     : standard QPSO - uniform random init + fixed linear alpha
  * "pso"          : particle swarm optimization
  * "ga"           : genetic algorithm
  * "sa"           : simulated annealing

Component-analysis switches (Section 4.8) degrade the improved variant:
  with_chaotic, with_adaptive, with_remap.
"""

import numpy as np

from config import (
    POP_SIZE, MAX_ITER, ALPHA_INIT, ALPHA_MIN, ALPHA_MAX,
    PSO_W, PSO_C1, PSO_C2, GA_POP, GA_CROSSOVER, GA_MUTATION,
    SA_INIT_TEMP, SA_COOLING, CONVERGENCE_FLUCTUATION_TOL,
    CONVERGENCE_PATIENCE, DEVIATION_THRESHOLD,
    LOGISTIC_MU, GUIDANCE_FUSION_RATIO,
)
from chaotic_init import chaotic_positions, distribution_entropy
from channel_model import principal_component


def _objective(codebook, W, idx):
    """Aggregate interference for an index assignment (Eq. (14))."""
    codes = codebook[:, np.asarray(idx, dtype=int)]
    return float(np.einsum("iu,ij,ju->", codes, W, codes))


def _indices_from_positions(pos, n_codes):
    idx = np.clip((pos * n_codes).astype(int), 0, n_codes - 1)
    return idx


def _evaluate_pop(codebook, W, pos):
    """Fitness of every particle (minimisation convention)."""
    n_codes = codebook.shape[1]
    n = pos.shape[0]
    fit = np.empty(n, dtype=float)
    for i in range(n):
        fit[i] = _objective(codebook, W, _indices_from_positions(pos[i], n_codes))
    return fit


def _qpos_update(pos, pbest, gbest, alpha):
    """Standard QPSO position update (Eq. (5))."""
    mbest = pbest.mean(axis=0)
    n, d = pos.shape
    phi = np.random.rand(n, d)
    p = phi * pbest + (1.0 - phi) * gbest
    u = np.random.rand(n, d)
    sign = np.where(np.random.rand(n, d) < 0.5, -1.0, 1.0)
    return p + sign * alpha * np.abs(mbest - p) * np.log(1.0 / (u + 1e-12))


def optimize_qpso(W, codebook, rng, user_dim, *,
                 chaotic=True, adaptive=True, remap=True,
                 variant="improved"):
    """Run a QPSO-family optimizer and return (best_obj, rounds, evals)."""
    Np = POP_SIZE
    U = user_dim
    n_codes = codebook.shape[1]

    # ---- initialisation ----
    if chaotic:
        pc = principal_component(W)
        pos = chaotic_positions(Np, U, pc, rng,
                                mu=LOGISTIC_MU,
                                beta=GUIDANCE_FUSION_RATIO)
    else:
        pos = rng.uniform(0.0, 1.0, size=(Np, U))

    fit = _evaluate_pop(codebook, W, pos)
    evals = Np
    pbest = pos.copy()
    pfit = fit.copy()
    gidx = int(np.argmin(fit))
    gbest_pos = pbest[gidx].copy()
    gbest_val = fit[gidx]

    prev_best = gbest_val
    quiet = 0
    alpha = ALPHA_INIT
    rounds = 0
    for it in range(1, MAX_ITER + 1):
        # ---- adaptive contraction-expansion coefficient (Eq. 7/8) ----
        if adaptive:
            fluctuation = float(np.mean(np.abs(fit - prev_best)))
            norm_fluct = fluctuation / (abs(gbest_val) + 1e-9)
            alpha = ALPHA_MIN + (ALPHA_MAX - ALPHA_MIN) * np.exp(-norm_fluct * 8.0)
        else:
            # fixed linearly decreasing schedule (degraded config)
            alpha = ALPHA_INIT - (ALPHA_INIT - ALPHA_MIN) * (it / MAX_ITER)

        # ---- position update ----
        new_pos = _qpos_update(pos, pbest, gbest_pos, alpha)
        new_pos = np.clip(new_pos, 0.0, 1.0)
        new_fit = _evaluate_pop(codebook, W, new_pos)
        evals += Np

        improved = new_fit < pfit
        pbest[improved] = new_pos[improved]
        pfit[improved] = new_fit[improved]

        cur_best = float(np.min(pfit))
        if cur_best < gbest_val:
            gidx = int(np.argmin(pfit))
            gbest_pos = pbest[gidx].copy()
            gbest_val = cur_best

        # ---- multi-round feedback remapping (Eq. 9) ----
        if remap and it % 5 == 0:
            dev = abs(prev_best - gbest_val) / (abs(prev_best) + 1e-9)
            if dev > DEVIATION_THRESHOLD:
                # re-seed the worst 30% of the swarm around the global best
                worst = np.argsort(pfit)[-max(1, Np // 3):]
                pc = principal_component(W)
                reseed = chaotic_positions(len(worst), U, pc, rng,
                                            mu=LOGISTIC_MU,
                                            beta=GUIDANCE_FUSION_RATIO)
                pbest[worst] = np.clip(gbest_pos + 0.1 * (reseed - 0.5), 0.0, 1.0)
                pos[worst] = pbest[worst]
                continue

        pos = new_pos
        rounds = it

        # ---- convergence test ----
        if abs(prev_best - gbest_val) < CONVERGENCE_FLUCTUATION_TOL:
            quiet += 1
            if quiet >= CONVERGENCE_PATIENCE:
                break
        else:
            quiet = 0
        prev_best = gbest_val

    return gbest_val, rounds, evals


def optimize_pso(W, codebook, rng, user_dim):
    """Standard PSO over the continuous relaxation of the assignment."""
    Np = POP_SIZE
    U = user_dim
    n_codes = codebook.shape[1]
    pos = rng.uniform(0.0, 1.0, size=(Np, U))
    vel = np.zeros((Np, U))
    fit = _evaluate_pop(codebook, W, pos)
    evals = Np
    pbest = pos.copy()
    pfit = fit.copy()
    gidx = int(np.argmin(fit))
    gbest_pos = pbest[gidx].copy()
    gbest_val = fit[gidx]

    rounds = 0
    prev_best = gbest_val
    quiet = 0
    for it in range(1, MAX_ITER + 1):
        r1 = rng.random((Np, U))
        r2 = rng.random((Np, U))
        vel = (PSO_W * vel + PSO_C1 * r1 * (pbest - pos)
               + PSO_C2 * r2 * (gbest_pos - pos))
        pos = np.clip(pos + vel, 0.0, 1.0)
        fit = _evaluate_pop(codebook, W, pos)
        evals += Np
        improved = fit < pfit
        pbest[improved] = pos[improved]
        pfit[improved] = fit[improved]
        cur = float(np.min(pfit))
        if cur < gbest_val:
            gidx = int(np.argmin(pfit))
            gbest_pos = pbest[gidx].copy()
            gbest_val = cur
        rounds = it
        if abs(prev_best - gbest_val) < CONVERGENCE_FLUCTUATION_TOL:
            quiet += 1
            if quiet >= CONVERGENCE_PATIENCE:
                break
        else:
            quiet = 0
        prev_best = gbest_val
    return gbest_val, rounds, evals


def optimize_ga(W, codebook, rng, user_dim):
    """Genetic algorithm over discrete index assignments."""
    Np = GA_POP
    U = user_dim
    n_codes = codebook.shape[1]
    pop = rng.integers(0, n_codes, size=(Np, U))
    fit = np.array([_objective(codebook, W, ind) for ind in pop])
    evals = Np
    best_idx = pop[int(np.argmin(fit))].copy()
    best_val = float(np.min(fit))

    rounds = 0
    prev_best = best_val
    quiet = 0
    for it in range(1, MAX_ITER + 1):
        order = np.argsort(fit)
        new_pop = pop[order[:max(1, Np // 8)]].copy()  # elitism
        while len(new_pop) < Np:
            a, b = rng.choice(Np, 2, replace=False)
            pa, pb = pop[a], pop[b]
            cut = rng.integers(0, U)
            child = np.concatenate([pa[:cut], pb[cut:]])
            for j in range(U):
                if rng.random() < GA_MUTATION:
                    child[j] = rng.integers(0, n_codes)
            new_pop = np.vstack([new_pop, child])
        pop = new_pop[:Np]
        fit = np.array([_objective(codebook, W, ind) for ind in pop])
        evals += Np
        cur = float(np.min(fit))
        if cur < best_val:
            best_idx = pop[int(np.argmin(fit))].copy()
            best_val = cur
        rounds = it
        if abs(prev_best - best_val) < CONVERGENCE_FLUCTUATION_TOL:
            quiet += 1
            if quiet >= CONVERGENCE_PATIENCE:
                break
        else:
            quiet = 0
        prev_best = best_val
    return best_val, rounds, evals


def optimize_sa(W, codebook, rng, user_dim):
    """Simulated annealing over discrete index assignments."""
    U = user_dim
    n_codes = codebook.shape[1]
    cur = rng.integers(0, n_codes, size=U)
    cur_val = _objective(codebook, W, cur)
    best = cur.copy()
    best_val = cur_val
    temp = SA_INIT_TEMP
    evals = 1
    rounds = 0
    prev_best = best_val
    quiet = 0
    for it in range(1, MAX_ITER + 1):
        for _ in range(max(U, 4)):
            nxt = cur.copy()
            nxt[rng.integers(0, U)] = rng.integers(0, n_codes)
            nxt_val = _objective(codebook, W, nxt)
            evals += 1
            delta = nxt_val - cur_val
            if delta < 0 or rng.random() < np.exp(-delta / max(temp, 1e-6)):
                cur, cur_val = nxt, nxt_val
                if cur_val < best_val:
                    best, best_val = cur.copy(), cur_val
        rounds = it
        temp *= SA_COOLING
        if abs(prev_best - best_val) < CONVERGENCE_FLUCTUATION_TOL:
            quiet += 1
            if quiet >= CONVERGENCE_PATIENCE:
                break
        else:
            quiet = 0
        prev_best = best_val
    return best_val, rounds, evals


def run_optimizer(variant, W, codebook, rng, user_dim,
                  chaotic=True, adaptive=True, remap=True):
    """Unified entry point returning (best_obj, rounds, evals)."""
    if variant == "improved":
        return optimize_qpso(W, codebook, rng, user_dim,
                             chaotic=chaotic, adaptive=adaptive,
                             remap=remap, variant="improved")
    if variant == "standard":
        return optimize_qpso(W, codebook, rng, user_dim,
                             chaotic=False, adaptive=False, remap=False,
                             variant="standard")
    if variant == "pso":
        return optimize_pso(W, codebook, rng, user_dim)
    if variant == "ga":
        return optimize_ga(W, codebook, rng, user_dim)
    if variant == "sa":
        return optimize_sa(W, codebook, rng, user_dim)
    raise ValueError(f"unknown variant: {variant}")
