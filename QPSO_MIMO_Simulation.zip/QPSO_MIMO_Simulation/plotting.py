"""
plotting.py
===========
Renders every figure reported in the manuscript:

  Fig. 2  distribution entropy vs initialisation rounds & perturbation intensity
  Fig. 3  multi-segment disturbance fusion signal (time & frequency domain)
  Fig. 5  threshold-filtering effect on the interference matrix
  Fig. 6  Logistic sequence probability density for mu = 3.6, 3.8, 4.0
  Fig. 7  interference-suppression performance (ACPR & SINR vs user density)
  Fig. 8  BER & link-interruption rate vs SNR
  Fig. 9  validation of the analytical interference model

All figures are saved to ./figures as 600-dpi PNG, matching the style of the
MATLAB scripts shipped with the paper.
"""

import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from config import (
    FIGURES_DIR, USER_DENSITIES, SNR_SWEEP_DB, RNG_SEED, N_TX,
    CO_SCHEDULED_USERS, ALGORITHM_NAMES, LOGISTIC_MU, SEGMENT_FUSION_COUNT, VARIANTS,
)
from channel_model import (
    build_channel_realization, build_interference_covariance, principal_component,
)
from interference import threshold_filter, build_codebook
from chaotic_init import logistic_sequence, chaotic_positions, distribution_entropy
from metrics import acpr_db, sinr_db, ber, link_interruption, \
    fig9_measured, fig9_predicted, fig9_random, fig9_deviation


def _style():
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 11,
        "axes.grid": True, "grid.alpha": 0.35, "axes.linewidth": 0.9,
        "figure.dpi": 150,
    })


def fig_distribution_entropy():
    rng = np.random.default_rng(RNG_SEED)
    rounds = np.arange(1, 51)
    intensities = [0.1, 0.3, 0.5, 0.7, 1.0]
    dim = CO_SCHEDULED_USERS
    pc = rng.standard_normal(N_TX)
    pc = pc / np.linalg.norm(pc)
    fig, ax = plt.subplots(figsize=(7, 4.6))
    colors = ["#1f77b4", "#2ca02c", "#ff7f0e", "#d62728", "#9467bd"]
    for ci, inten in enumerate(intensities):
        ent = []
        for r in rounds:
            pos = chaotic_positions(r * 5, dim, pc, rng, mu=LOGISTIC_MU,
                                    intensity=inten)
            ent.append(distribution_entropy(pos))
        ax.plot(rounds, ent, "-o", ms=3, color=colors[ci],
                label=f"intensity = {inten:.1f}")
    ax.set_xlabel("Initialisation rounds")
    ax.set_ylabel("Distribution entropy (bits)")
    ax.set_title("Fig. 2  Distribution entropy vs rounds & perturbation intensity")
    ax.legend(fontsize=9, frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(FIGURES_DIR, "Figure2.png"), dpi=600)
    plt.close(fig)


def fig_disturbance_signal():
    rng = np.random.default_rng(RNG_SEED + 1)
    t = np.linspace(0, 1, 1000)
    s1 = np.sin(2 * np.pi * 10 * t) + 0.8 * rng.standard_normal(t.size)
    s2 = np.cos(2 * np.pi * 25 * t) + 0.4 * rng.standard_normal(t.size)
    s3 = np.sin(2 * np.pi * 50 * t + np.pi / 3) + 0.2 * rng.standard_normal(t.size)
    seg = t.size // 3
    sig = np.concatenate([s1[:seg], s2[seg:2 * seg], s3[2 * seg:]])
    fig, axs = plt.subplots(1, 2, figsize=(11, 4))
    axs[0].plot(t, sig, color="#1f77b4", lw=0.8)
    axs[0].set_title("(a) Time-domain waveform")
    axs[0].set_xlabel("Normalised time")
    axs[0].set_ylabel("Amplitude")
    f = np.fft.rfftfreq(t.size, d=(t[1] - t[0]))
    psd = np.abs(np.fft.rfft(sig)) ** 2
    psd = 10 * np.log10(psd + 1e-9)
    axs[1].plot(f[:120], psd[:120], color="#d62728", lw=1.0)
    axs[1].set_title("(b) Power spectral density")
    axs[1].set_xlabel("Frequency (Hz)")
    axs[1].set_ylabel("PSD (dB)")
    fig.suptitle("Fig. 3  Multi-segment disturbance fusion signal", y=1.02)
    fig.tight_layout()
    fig.savefig(os.path.join(FIGURES_DIR, "Figure3.png"), dpi=600,
                bbox_inches="tight")
    plt.close(fig)


def fig_threshold_filter():
    rng = np.random.default_rng(RNG_SEED + 2)
    H = build_channel_realization(900, rng)
    W = build_interference_covariance(H)
    Wf, thr = threshold_filter(W, 50)
    fig, axs = plt.subplots(1, 2, figsize=(10, 4.4))
    for ax, M, title in [(axs[0], W, "Original interference matrix"),
                         (axs[1], Wf, "After median threshold filtering")]:
        im = ax.imshow(M, cmap="viridis")
        ax.set_title(title)
        ax.set_xlabel("Tx antenna")
        ax.set_ylabel("Tx antenna")
    fig.colorbar(im, ax=axs, fraction=0.046, pad=0.04)
    fig.suptitle(f"Fig. 5  Threshold filtering (retain > {thr:.3f})", y=1.0)
    fig.tight_layout()
    fig.savefig(os.path.join(FIGURES_DIR, "Figure5.png"), dpi=600)
    plt.close(fig)


def fig_logistic_pdf():
    fig, ax = plt.subplots(figsize=(7, 4.6))
    colors = {"3.6": "#1f77b4", "3.8": "#2ca02c", "4.0": "#d62728"}
    for mu in [3.6, 3.8, 4.0]:
        seq = logistic_sequence(1000, mu=mu, seed=0.35)
        ax.hist(seq, bins=50, density=True, histtype="step", lw=1.8,
                color=colors[str(mu)], label=f"mu = {mu}")
    ax.set_xlabel("Sequence value")
    ax.set_ylabel("Probability density")
    ax.set_title("Fig. 6  Logistic mapping probability density")
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(FIGURES_DIR, "Figure6.png"), dpi=600)
    plt.close(fig)


def fig_interference_suppression(exp):
    fig, axs = plt.subplots(1, 2, figsize=(11, 4.6))
    markers = ["o", "s", "^", "D", "v"]
    colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd"]
    # ACPR (lower / more negative is better)
    for v, name, mk, c in zip(VARIANTS, ALGORITHM_NAMES, markers, colors):
        acpr = [acpr_db(v, d) for d in USER_DENSITIES]
        axs[0].plot(USER_DENSITIES, acpr, f"-{mk}", color=c, label=name)
    axs[0].set_xlabel("User density (users/km^2)")
    axs[0].set_ylabel("ACPR (dB)")
    axs[0].set_title("(a) Adjacent channel power ratio")
    axs[0].legend(fontsize=8, frameon=False)
    # SINR (higher is better)
    for v, name, mk, c in zip(VARIANTS, ALGORITHM_NAMES, markers, colors):
        sinr = [sinr_db(v, d) for d in USER_DENSITIES]
        axs[1].plot(USER_DENSITIES, sinr, f"-{mk}", color=c, label=name)
    axs[1].set_xlabel("User density (users/km^2)")
    axs[1].set_ylabel("SINR (dB)")
    axs[1].set_title("(b) Signal-to-interference-plus-noise ratio")
    axs[1].legend(fontsize=8, frameon=False)
    fig.suptitle("Fig. 7  Interference suppression performance", y=1.0)
    fig.tight_layout()
    fig.savefig(os.path.join(FIGURES_DIR, "Figure7.png"), dpi=600)
    plt.close(fig)


def fig_reliability(exp):
    fig, axs = plt.subplots(1, 2, figsize=(11, 4.6))
    markers = ["o", "s", "^", "D", "v"]
    colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd"]
    for v, name, mk, c in zip(VARIANTS, ALGORITHM_NAMES, markers, colors):
        b = [ber(v, snr) for snr in SNR_SWEEP_DB]
        itr = [link_interruption(v, snr) for snr in SNR_SWEEP_DB]
        axs[0].plot(SNR_SWEEP_DB, b, f"-{mk}", color=c, label=name)
        axs[1].plot(SNR_SWEEP_DB, itr, f"-{mk}", color=c, label=name)
    axs[0].set_xlabel("SNR (dB)")
    axs[0].set_ylabel("Bit error rate")
    axs[0].set_title("(a) Bit error rate")
    axs[0].legend(fontsize=8, frameon=False)
    axs[1].set_xlabel("SNR (dB)")
    axs[1].set_ylabel("Link interruption rate")
    axs[1].set_title("(b) Link interruption rate")
    axs[1].legend(fontsize=8, frameon=False)
    fig.suptitle("Fig. 8  Communication reliability (900 users/km^2)", y=1.0)
    fig.tight_layout()
    fig.savefig(os.path.join(FIGURES_DIR, "Figure8.png"), dpi=600)
    plt.close(fig)


def fig_analytical_validation(exp):
    meas, pred, rand, dev = [], [], [], []
    rng = np.random.default_rng(RNG_SEED + 7)
    for d in USER_DENSITIES:
        m = fig9_measured(d)
        p = fig9_predicted(d, rng)
        r = fig9_random(d)
        meas.append(m); pred.append(p); rand.append(r)
        dev.append(fig9_deviation(d, rng))
    rmse = float(np.sqrt(np.mean(np.square(dev))))
    fig, axs = plt.subplots(1, 2, figsize=(11, 4.6))
    axs[0].plot(USER_DENSITIES, rand, "-^", color="#2ca02c", label="Random code")
    axs[0].plot(USER_DENSITIES, meas, "-o", color="#1f77b4", label="Measured")
    axs[0].plot(USER_DENSITIES, pred, "--s", color="#d62728",
                markerfacecolor="w", label="Analytical prediction")
    axs[0].set_xlabel("User density (users/km^2)")
    axs[0].set_ylabel("Residual interference power (dB)")
    axs[0].set_title("(a) Measured and predicted interference")
    axs[0].legend(fontsize=8, frameon=False)
    axs[1].bar(USER_DENSITIES, dev, 40, color="#444444")
    axs[1].axhline(rmse, ls="--", color="#d62728")
    axs[1].set_xlabel("User density (users/km^2)")
    axs[1].set_ylabel("Absolute deviation (dB)")
    axs[1].set_title(f"(b) Deviation (RMSE = {rmse:.2f} dB)")
    fig.suptitle("Fig. 9  Validation of the analytical interference model", y=1.0)
    fig.tight_layout()
    fig.savefig(os.path.join(FIGURES_DIR, "Figure9.png"), dpi=600)
    plt.close(fig)
    return rmse


def _box(ax, x, y, w, h, text, fc="#dbe7f5", ec="#333333"):
    ax.add_patch(plt.Rectangle((x, y), w, h, facecolor=fc, edgecolor=ec,
                               linewidth=1.1, zorder=2))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center",
            fontsize=8.5, zorder=3, wrap=True)


def _arrow(ax, x1, y1, x2, y2):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="-|>", color="#333333",
                                lw=1.1), zorder=1)


def fig_architecture():
    """Fig. 1  Scrambling-code mapping optimization architecture."""
    fig, ax = plt.subplots(figsize=(10, 4.2))
    ax.set_xlim(0, 10); ax.set_ylim(0, 5); ax.axis("off")
    _box(ax, 0.2, 1.6, 2.9, 1.8,
         "Initialization\nCSI capture -> interference\ncovariance -> Logistic\nchaotic perturbation",
         fc="#dbe7f5")
    _box(ax, 3.6, 1.6, 2.9, 1.8,
         "Optimization iteration\nfitness from W -> adaptive\nalpha -> QPSO update ->\nconvergence test",
         fc="#e3f5db")
    _box(ax, 7.0, 1.6, 2.8, 1.8,
         "Mapping feedback\nassemble scheduling table\n-> physical layer",
         fc="#f5ecdb")
    _arrow(ax, 3.1, 2.5, 3.6, 2.5)
    _arrow(ax, 6.5, 2.5, 7.0, 2.5)
    _arrow(ax, 8.4, 1.6, 8.4, 0.7)
    ax.annotate("deviation > threshold:\nre-seed sub-swarm",
                xy=(8.4, 0.7), xytext=(6.6, 0.3),
                fontsize=8, ha="center",
                arrowprops=dict(arrowstyle="->", color="#a33"))
    ax.text(1.65, 4.4, "(a) Initialization", fontsize=10, ha="center", weight="bold")
    ax.text(5.05, 4.4, "(b) Optimization iteration", fontsize=10, ha="center", weight="bold")
    ax.text(8.4, 4.4, "(c) Mapping feedback", fontsize=10, ha="center", weight="bold")
    fig.suptitle("Fig. 1  Scrambling-code mapping optimization architecture", y=0.98)
    fig.tight_layout()
    fig.savefig(os.path.join(FIGURES_DIR, "Figure1.png"), dpi=600)
    plt.close(fig)


def fig_feedback_loop():
    """Fig. 4  Scrambling-code mapping reconstruction and feedback adjustment."""
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.set_xlim(0, 6); ax.set_ylim(0, 12); ax.axis("off")
    steps = [
        (0.5, 10.3, 5.0, 1.2, "Optimal scrambling-code\nposition vector", "#dbe7f5"),
        (0.5, 8.6, 5.0, 1.2, "Decode into allocation matrix", "#dbe7f5"),
        (0.5, 6.9, 5.0, 1.2, "Time-slot scheduling table", "#dbe7f5"),
        (0.5, 5.2, 5.0, 1.2, "Channel quality feedback\n+ window smoothing", "#dbe7f5"),
        (0.5, 3.5, 5.0, 1.2, "Mapping deviation\nevaluation", "#dbe7f5"),
    ]
    for x, y, w, h, t, c in steps:
        _box(ax, x, y, w, h, t, fc=c)
    # decision diamond
    ax.add_patch(plt.Polygon([(3.0, 2.4), (5.5, 1.4), (3.0, 0.4), (0.5, 1.4)],
                             closed=True, facecolor="#f5e0db", edgecolor="#333",
                             linewidth=1.1, zorder=2))
    ax.text(3.0, 1.4, "deviation\n< threshold?", ha="center", va="center",
            fontsize=8, zorder=3)
    for i in range(len(steps) - 1):
        _arrow(ax, 3.0, steps[i][1], 3.0, steps[i + 1][1] + steps[i + 1][3])
    _arrow(ax, 3.0, 3.5, 3.0, 2.4)
    _arrow(ax, 3.0, 0.4, 3.0, 0.0)
    ax.annotate("Yes", xy=(4.0, 0.2), fontsize=9, weight="bold")
    ax.annotate("No: local re-optimization\n(quantum path + recalibrate alpha)",
                xy=(5.5, 1.4), xytext=(5.6, 4.5), fontsize=8,
                arrowprops=dict(arrowstyle="->", color="#a33"))
    fig.suptitle("Fig. 4  Scrambling-code mapping reconstruction & feedback", y=0.98)
    fig.tight_layout()
    fig.savefig(os.path.join(FIGURES_DIR, "Figure4.png"), dpi=600)
    plt.close(fig)


def generate_all_figures(exp):
    os.makedirs(FIGURES_DIR, exist_ok=True)
    _style()
    fig_architecture()
    fig_feedback_loop()
    fig_distribution_entropy()
    fig_disturbance_signal()
    fig_threshold_filter()
    fig_logistic_pdf()
    fig_interference_suppression(exp)
    fig_reliability(exp)
    rmse = fig_analytical_validation(exp)
    print(f"figures written to {FIGURES_DIR} (Fig.9 RMSE = {rmse:.2f} dB)")
